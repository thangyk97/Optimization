package choco;

import choco.cp.model.CPModel;

public class NQueenChoco {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CPModel m = new CPModel();
	}

}
