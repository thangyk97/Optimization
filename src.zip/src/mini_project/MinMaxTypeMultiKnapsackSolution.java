package mini_project;

public class MinMaxTypeMultiKnapsackSolution {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println((int) 0.99999);
	}

}
